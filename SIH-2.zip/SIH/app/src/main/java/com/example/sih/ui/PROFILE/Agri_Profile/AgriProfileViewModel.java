package com.example.sih.ui.PROFILE.Agri_Profile;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.lifecycle.ViewModel;

import com.example.sih.R;

import java.util.List;

public class AgriProfileViewModel extends ViewModel {


    public static class Item {
        boolean checked;
        String ItemString;

        Item(String t, boolean b) {
            ItemString = t;
            checked = b;
        }

        public boolean isChecked() {
            return checked;
        }
    }

    static class ViewHolder {
        CheckBox checkBox;
        TextView text;
    }

    public static class ItemsListAdapter extends BaseAdapter {

        private Context context;
        private List<Item> list;
        private int list_item, crops;

        ItemsListAdapter(Context c, List<Item> l) {
            context = c;
            list = l;
        }

        ItemsListAdapter(Context c, int simple_list_item_1, int crop_type) {
            context = c;
            list_item =simple_list_item_1;
            crops = crop_type;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public boolean isChecked(int position) {
            return list.get(position).checked;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View rowView = convertView;

            // reuse views
            ViewHolder viewHolder = new ViewHolder();
            if (rowView == null) {
                LayoutInflater inflater = ((Activity) context).getLayoutInflater();
                rowView = inflater.inflate(R.layout.checkbox_listview, null);

                viewHolder.checkBox = rowView.findViewById(R.id.cb);
                viewHolder.text = rowView.findViewById(R.id.cname);
                rowView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) rowView.getTag();
            }

            viewHolder.checkBox.setChecked(list.get(position).checked);

            final String itemStr = list.get(position).ItemString;
            viewHolder.text.setText(itemStr);

            viewHolder.checkBox.setTag(position);


            viewHolder.checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    boolean newState = !list.get(position).isChecked();
                    list.get(position).checked = newState;
                    Toast.makeText(context, itemStr + "setOnClickListener\nchecked: " + newState,
                            Toast.LENGTH_LONG).show();

                }
            });

            viewHolder.checkBox.setChecked(isChecked(position));

            return rowView;
        }
    }

}